class Arith2 {
    public static void main(String[] args) {
        // 0 * @ of object
        System.out.println(1 + 0 * new A());
    }
}

class A {
}
