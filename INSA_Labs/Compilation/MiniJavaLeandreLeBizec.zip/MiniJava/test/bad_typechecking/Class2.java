class Class2 {
    public static void main(String[] args) {
        // Class C must be defined
        System.out.println(new C().init());
    }
}