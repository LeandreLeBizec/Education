class Call4 {
    public static void main(String[] args) {
        // 'init' does not exist
        System.out.println(new C().init());
    }
}

class C {
}
