class Arith1 {
    public static void main(String[] args) {
        // Integer * boolean
        System.out.println(1 + 2 * true);
    }
}
