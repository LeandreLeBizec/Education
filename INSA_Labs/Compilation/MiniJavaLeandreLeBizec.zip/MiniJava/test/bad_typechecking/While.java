class If {
    public static void main(String[] args) {
        // Boolean expected
        while (1) {
            System.out.println(1);
        }
    }
}