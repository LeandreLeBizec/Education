class If {
    public static void main(String[] args) {
        // Boolean expected
        if (1 + 2) {
            System.out.println(1);
        } else {
            System.out.println(0);
        }
    }
}