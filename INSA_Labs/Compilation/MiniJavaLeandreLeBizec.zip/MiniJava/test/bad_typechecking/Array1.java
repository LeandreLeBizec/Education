class Array1 {
    public static void main(String[] args) {
        System.out.println(new A().init());
    }
}

class A {
    public int init() {
        int[] a;
        // Size of array must be an integer
        a = new int[1 + 2 < 5];
        return 0;
    }
}