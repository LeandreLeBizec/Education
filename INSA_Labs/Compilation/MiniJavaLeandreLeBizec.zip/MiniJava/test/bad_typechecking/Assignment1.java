class Assignment1 {
    public static void main(String[] args) {
        System.out.println(new A().init());
    }
}

class A {
    public int init() {
        int a;
        boolean b;
        // Boolean assigns to integer
        a = b;
        return 0;
    }
}
