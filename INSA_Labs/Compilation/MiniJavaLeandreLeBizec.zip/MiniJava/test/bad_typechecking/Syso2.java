class Syso2 {
    public static void main(String[] args) {
        // Syso, in MiniJava, prints only integers
        System.out.println(true);
    }
}
