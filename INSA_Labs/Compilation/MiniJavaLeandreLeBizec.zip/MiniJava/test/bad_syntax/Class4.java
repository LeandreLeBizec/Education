class Class4 {
    public static void main(String[] args) {
        System.out.println(new C());
    }
}

class C {
    // No constructor declaration in MiniJava
    public C() {
    }
}