class Method4 {
    public static void main(String[] args) {
        System.out.println(new M());
    }
}

class M {
    // return type is missing
    public m(int a, int b) {
        return a + b;
    }
}