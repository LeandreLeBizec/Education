class Comments1 {
    public static void main(String[] args) {
        System.out.println(new C());
    }
}
/*
  Bad comment, should be closed

class C {
}