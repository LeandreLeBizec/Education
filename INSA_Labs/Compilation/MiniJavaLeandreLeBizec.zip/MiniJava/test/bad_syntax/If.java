class If {
    public static void main(String[] args) {
        // 'else' part is missing
        if (1 == 1) {
            System.out.println(42);
        }
    }
}