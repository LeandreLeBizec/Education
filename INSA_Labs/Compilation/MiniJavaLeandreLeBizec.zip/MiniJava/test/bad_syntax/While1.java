class While1 {
    public static void main(String[] args) {
        // Missing condition in 'while'
        while () {

        }
    }
}
