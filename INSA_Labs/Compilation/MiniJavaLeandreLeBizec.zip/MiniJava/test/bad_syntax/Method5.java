class Method5 {
    public static void main(String[] args) {
        System.out.println(new M());
    }
}

class M {
    public int m(int a, int b) {
        int c;
        while (true) {
        }
        // All declarations should appear at the beginning of the method
        int d;
        return a + b;
    }
}