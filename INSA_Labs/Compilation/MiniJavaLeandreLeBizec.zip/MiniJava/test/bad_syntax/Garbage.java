class Garbage {
    public static void main(String[] args) {
        System.out.println(42);
    }
}
// Only class definitions should appear here
MrCoder