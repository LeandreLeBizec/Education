class Brace {
    public static void main(String[] args) {
        System.out.println(42);
    }
}
// Extra brace here
}