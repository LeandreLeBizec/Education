class Main2 {
    // String[] argument is missing
    public static void main() {
        System.out.println(42);
    }
}
