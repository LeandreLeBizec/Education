class Class2 {
    public static void main(String[] args) {
        System.out.println(new C());
    }
}

// Need an identifier after extends
class C extends {
}