class Array2 {
    public static void main(String[] args) {
        System.out.println(new A());
    }
}

class A {
    public int[] m() {
        int[] a;
        // Index is missing
        a[] = 25031975;
        return a;
    }
}
