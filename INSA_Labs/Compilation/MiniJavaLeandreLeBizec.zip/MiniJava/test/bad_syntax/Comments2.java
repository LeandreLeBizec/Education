class Comments2 {
    public static void main(String[] args) {
        System.out.println(42);
    }
}
// In the comment below, the last */ does not belong to the comment
/* */ */
class C {
}