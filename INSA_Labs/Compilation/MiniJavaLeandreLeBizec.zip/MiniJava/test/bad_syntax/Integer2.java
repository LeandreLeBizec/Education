class Integer2 {
    public static void main(String[] args) {
        // No negative integer literal in MiniJava
        System.out.println(-1);
    }
}