class Main1 {
    // static keyword is missing
    public void main(String[] args) {
        System.out.println(42);
    }
}
