class Integer1 {
    public static void main(String[] args) {
        // Integer constant too big, maximum is 2^31 - 1 = 2147483647
        System.out.println(2147483648);
    }
}
