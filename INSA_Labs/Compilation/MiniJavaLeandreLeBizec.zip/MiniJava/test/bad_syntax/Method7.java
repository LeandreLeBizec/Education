class Method7 {
    public static void main(String[] args) {
        System.out.println(new M());
    }
}

class M {
    // The 'public' keyword is missing
    int m() {
        return 0;
    }
}