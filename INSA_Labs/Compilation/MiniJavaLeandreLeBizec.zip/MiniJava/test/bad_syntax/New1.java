class New1 {
    public static void main(String[] args) {
        // Missing parenthesis after 'C'
        System.out.println(new C);
    }
}

class C {
}