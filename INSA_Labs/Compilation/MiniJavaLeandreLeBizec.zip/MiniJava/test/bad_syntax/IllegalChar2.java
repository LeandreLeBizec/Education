class IllegalChar2 {
    public static void main(String[] args) {
        // Illegal lexem '"'
        System.out.println("MiniJava");
    }
}