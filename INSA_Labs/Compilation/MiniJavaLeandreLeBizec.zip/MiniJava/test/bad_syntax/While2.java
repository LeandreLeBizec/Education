class While2 {
    public static void main(String[] args) {
        // Missing instruction in 'while'
        while (true);
    }
}
