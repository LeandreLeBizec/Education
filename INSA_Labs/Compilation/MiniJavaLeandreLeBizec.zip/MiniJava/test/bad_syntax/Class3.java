class Class3 {
    public static void main(String[] args) {
        System.out.println(new C());
    }
}

class C {
    public int m(int a) {
        return 0;
    }
    // All attributes must be declared before all methods
    int att;
}