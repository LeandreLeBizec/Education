class Method3 {
    public static void main(String[] args) {
        System.out.println(new M());
    }
}

class M {
    public int m(int a, int b) {
        // 'return' statement is missing
    }
}