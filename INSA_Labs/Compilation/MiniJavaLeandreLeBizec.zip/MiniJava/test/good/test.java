class test{
    public static void main(String[] a) {
       System.out.println(new Main().testTyp());
    }
}

class Main{
    public int testTyp(){
        int i;
        float f;
        String res;
        i = 1+1;
        f=3.14+3.14;
        res = "result";
        System.out.println(i);
        System.out.println(f);
        System.out.println(res);
        return 0;
    }

    public int testIf(){
        if(1!=0){
            if(1.3 == 1.3){
                System.out.println(1);
            }
        }else{
            System.out.println(0);
        }
        return 01;
    }

    public int testWhile(){
        int i;
        i=0;
        while(i<3){
            System.out.println(i);
            i = i+1;
        }
        return 02;    
    }

    public int testFor(){
        int i;
        for(i=0;i<3;i=i+1){
            System.out.println(i);
        }
        return 03;
    }
}