/*
class test {
  public static void main(String[] a) {
    System.out.println(new Main().testTyp());
  }
}
class Main {
  public int testTyp() {
    int i;
    float f;
    string res;
    i = 1 + 1;
    f = 3.140000 + 3.140000;
    res = "result;
    System.out.println(i);
    System.out.println(f);
    System.out.println(res);
    return 0;
  }
  public int testIf() {
    if (1 != 0) {
      if (1.300000 == 1.300000) {
        System.out.println(1);
      }
    }
    else {
      System.out.println(0);
    }
    return 1;
  }
  public int testWhile() {
    int i;
    i = 0;
    while (i < 3) {
      System.out.println(i);
      i = i + 1;
    }
    return 2;
  }
  public int testFor() {
    int i;
    {
      i = 0;
      while (i < 3) {
        {
          System.out.println(i);
        }
        i = i + 1;
      }
    }
    return 3;
  }
}*/
#include <stdio.h>
#include <stdlib.h>
#include "tgc.h"
#pragma GCC diagnostic ignored "-Wpointer-to-int-cast"
#pragma GCC diagnostic ignored "-Wint-to-pointer-cast"
struct array { int* array; int length; };
tgc_t gc;
struct Main;
void* Main_testTyp(struct Main* this);
void* Main_testIf(struct Main* this);
void* Main_testWhile(struct Main* this);
void* Main_testFor(struct Main* this);
struct Main {
  void* (**vtable)();
};
void* (*Main_vtable[])() = { Main_testTyp, Main_testIf, Main_testWhile, Main_testFor };
void* Main_testTyp(struct Main* this) {
  int i;
  float f;
  char* res;
  i = (1 + 1);
  f = (3.140000 + 3.140000);
  res = "result";
  printf("%d\n", i);
  printf("%f\n", f);
  printf("%s\n", res);
  return (void*)(0);
}
void* Main_testIf(struct Main* this) {
  if ((1 != 0)) {
    if ((1.300000 == 1.300000)) {
      printf("%d\n", 1);
    }
  }
  else {
    printf("%d\n", 0);
  }
  return (void*)(1);
}
void* Main_testWhile(struct Main* this) {
  int i;
  i = 0;
  while ((i < 3)) {
    printf("%d\n", i);
    i = (i + 1);
  }
  return (void*)(2);
}
void* Main_testFor(struct Main* this) {
  int i;
  {
    i = 0;
    while ((i < 3)) {
      {
        printf("%d\n", i);
      }
      i = (i + 1);
    }
  }
  return (void*)(3);
}
int main(int argc, char *argv[]) {
  tgc_start(&gc, &argc);
  printf("%d\n", ({ struct Main* tmp1 = ({ struct Main* res = tgc_calloc(({ extern tgc_t gc; &gc; }), 1, sizeof(*res)); res->vtable = Main_vtable; res; }); (int) tmp1->vtable[0](tmp1); }));
  tgc_stop(&gc);

  return 0;
}
