class MessWithTmpVariables {
    public static void main(String[] tmp2) {
        System.out.println(new M().tmp2(42));
    }
}

class M {
    int tmp1;
    int tmp1_;

    public int tmp2(int tmp1__) {
        int tmp1___;
        int[] res;
        int[] a;
        M m;
        a = new int[tmp1__];
        m = new M();
        return tmp1__;
    }
}