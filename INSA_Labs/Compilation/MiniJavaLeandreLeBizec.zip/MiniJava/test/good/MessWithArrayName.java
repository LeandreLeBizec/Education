class MessWithArrayName {
    public static void main(String[] args) {
        System.out.println(new array().run());
    }
}

class array {
    public int run() {
        int[] array;
        array = new int[42];
        return 0;
    }
}

class array_ {
}

class array__ {
}

class array___ {
}

class array____ {
}